package com.example.new_project.config;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class CustomFileReader {
    public List<String> readFile(String path) throws IOException {
        BufferedReader reader = Files.newBufferedReader(Paths.get(path));
        List<String> strings = reader.lines().toList();
        reader.reset();
        return strings;
    }
}
