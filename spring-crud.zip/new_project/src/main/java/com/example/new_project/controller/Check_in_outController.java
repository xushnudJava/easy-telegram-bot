package com.example.new_project.controller;

import com.example.new_project.dto.CheckDto;
import com.example.new_project.entity.Check_in_out;
import com.example.new_project.entity.Employee;
import com.example.new_project.repo.Check_in_outRepo;
import com.example.new_project.repo.EmployeeRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Optional;

@RestController
public class Check_in_outController {
    @Autowired
    Check_in_outRepo check_in_outRepo;
    @Autowired
    EmployeeRepo employeeRepo;
    @RequestMapping(value = "/check",method = RequestMethod.POST)
    public String addCheck(@RequestBody CheckDto checkDto){
        Optional<Employee> byId = employeeRepo.findById(checkDto.getEmployee_id());
        if (byId.isPresent()){
            Employee employee = byId.get();
            Check_in_out checkInOut = new Check_in_out();
            checkInOut.setCheck_in(checkDto.getCheck_in());
            checkInOut.setCheck_out(checkDto.getCheck_out());
            checkInOut.setDate(checkDto.getDate());
            checkInOut.setEmployee(employee);
            check_in_outRepo.save(checkInOut);
            return "add check in out";
        }else return "empployee id bo'yicha malumot topilmadi";
    }
    @RequestMapping(value = "/check/{id}",method = RequestMethod.GET)
    public List<Check_in_out> getCheckList(@PathVariable Integer id){
        Optional<Employee> byId = employeeRepo.findById(id);
        if (byId.isPresent()) {
            List<Check_in_out> allByEmployee = check_in_outRepo.findAllByEmployee(byId.get());
            return allByEmployee;
        }else return null;
    }
    @RequestMapping(value = "/check/{id}",method = RequestMethod.DELETE)
    public String deleteCheck(@PathVariable Integer id){
        Optional<Check_in_out> byId = check_in_outRepo.findById(id);
        if (byId.isPresent()){
            check_in_outRepo.delete(byId.get());
            return "deleted";
        }else return "id bo'yicha employee topilmadi";
    }
    @RequestMapping(value = "/check/{id}",method = RequestMethod.PUT)
    public String updateCheck(@PathVariable Integer id, @RequestBody CheckDto checkDto){
        Optional<Employee> byId = employeeRepo.findById(checkDto.getEmployee_id());
        if (byId.isPresent()){
            Employee employee = byId.get();
            Check_in_out check_in_out = new Check_in_out();
            if (checkDto.getCheck_in() != null) check_in_out.setCheck_in(checkDto.getCheck_in());
            if (checkDto.getCheck_out() != null) check_in_out.setCheck_out(checkDto.getCheck_out());
            if (checkDto.getDate() != null) check_in_out.setDate(checkDto.getDate());
            check_in_out.setEmployee(employee);
            check_in_outRepo.save(check_in_out);
            return "updated";
        }else return "employe_id bo'yicha employe topilmadi";
    }
}
