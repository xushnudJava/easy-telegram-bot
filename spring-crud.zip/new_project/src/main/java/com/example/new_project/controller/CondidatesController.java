package com.example.new_project.controller;

import com.example.new_project.entity.Candidates;
import com.example.new_project.repo.CondidatesRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Optional;

@RestController
public class CondidatesController {
    @Autowired
    CondidatesRepo condidatesRepo;
    @RequestMapping(value = "/condidates",method = RequestMethod.GET)
    public List<Candidates> getCondidateList(){
        return condidatesRepo.findAll();
    }
    @RequestMapping(value = "/condidates/{id}",method = RequestMethod.GET)
    public Candidates getCondidates(@PathVariable Integer id){
        Optional<Candidates> byId = condidatesRepo.findById(id);
        return byId.get();
    }
    @RequestMapping(value = "/condidates/{id}",method = RequestMethod.DELETE)
    public String deleteCondidates(@PathVariable Integer id){
        Optional<Candidates> byId = condidatesRepo.findById(id);
        if (byId.isPresent()){
            condidatesRepo.delete(byId.get());
            return "condidates delete";
        }else return "id boyicha condidate topilmadi";
    }
    @RequestMapping(value = "/condidates/{id}",method = RequestMethod.POST)
    public String addCondidates(@RequestBody Candidates candidates){
        if (candidates != null){
            condidatesRepo.save(candidates);
            return "added condidates";
        }else return "Error";
    }
    @RequestMapping(value = "/condidates/{id}",method = RequestMethod.PUT)
    public String updateCondidates(@PathVariable Integer id, @RequestBody Candidates candidates){
        Optional<Candidates> byId = condidatesRepo.findById(id);
        if (byId.isPresent()){
            Candidates candidates1 = byId.get();
            if (candidates.getFirstName() != null) candidates1.setFirstName(candidates.getFirstName());
            if (candidates.getLastName() != null) candidates1.setLastName(candidates.getLastName());
            if (candidates.getPositionTitle() != null) candidates1.setPositionTitle(candidates.getPositionTitle());
            if (candidates.getSkills() != null) candidates1.setSkills(candidates.getSkills());
            if (candidates.getExperiense() != null) candidates1.setExperiense(candidates.getExperiense());
            if (candidates.getExperSphere() != null) candidates1.setExperSphere(candidates.getExperSphere());
            if (candidates.getStatus() != null) candidates1.setStatus(candidates.getStatus());
            if (candidates.getComments() != null) candidates1.setComments(candidates.getComments());
            condidatesRepo.save(candidates1);
            return "Condidate update";
        }else return "id bo'yicha Condidate topilmadi";
    }

}
