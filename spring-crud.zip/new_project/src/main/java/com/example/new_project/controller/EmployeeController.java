package com.example.new_project.controller;

import com.example.new_project.entity.Employee;
import com.example.new_project.repo.EmployeeRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Optional;

@RestController
public class EmployeeController {
    @Autowired
    EmployeeRepo employeeRepo;
    @RequestMapping(value = "/employee",method = RequestMethod.GET)
    public List<Employee> getEmployeList(){
        return employeeRepo.findAll();
    }
    @RequestMapping(value = "/employee",method = RequestMethod.POST)
    public String addEmployee(@RequestBody Employee employee){
        if (employee != null) {
            employeeRepo.save(employee);
            return "Employee added";
        }else return "Error";

    }
    @RequestMapping(value = "/employee/{id}",method = RequestMethod.DELETE)
    public String deleteEmployee(@PathVariable Integer id){
        Optional<Employee> byId = employeeRepo.findById(id);
        if (byId.isPresent()){
            Employee employee = byId.get();
            employeeRepo.delete(employee);
            return "delete employee";
        }else return "employee topilmadi";
    }
    @RequestMapping(value = "/employee/{id}",method = RequestMethod.PUT)
    public String updateEmployee(@RequestBody Employee employee, @PathVariable Integer id){
        Optional<Employee> byId = employeeRepo.findById(id);
        if (byId.isPresent()){
            Employee employee1 = byId.get();
            if (employee.getFirstName() != null) employee1.setFirstName(employee.getFirstName());
            if (employee.getLastName() != null) employee1.setLastName(employee.getLastName());
            if (employee.getBirthday() != null) employee1.setBirthday(employee.getBirthday());
            if (employee.getGender() != null) employee1.setGender(employee.getGender());
            if (employee.getMaritalStatus() != null) employee1.setMaritalStatus(employee.getMaritalStatus());
            if (employee.getPhoneNumber() != null) employee1.setPhoneNumber(employee.getPhoneNumber());
            if (employee.getEmail_id() != null) employee1.setEmail_id(employee.getEmail_id());
            if (employee.getMode() != null) employee1.setMode(employee.getMode());
            if (employee.getHireDate() != null) employee1.setHireDate(employee.getHireDate());
            if (employee.getResignationDate() != null) employee1.setResignationDate(employee.getResignationDate());
            if (employee.getProbationPeriod() != null) employee1.setProbationPeriod(employee.getProbationPeriod());
            if (employee.getRole() != null) employee1.setRole(employee.getRole());
            if (employee.getSalary() != null) employee1.setSalary(employee.getSalary());
            if (employee.getReportingManager() != null) employee1.setReportingManager(employee.getReportingManager());
            employeeRepo.save(employee1);
            return "updated Employee";
        }else return "id bo'yicha employee topilmadi";
    }
    @RequestMapping(value = "/employee/{id}",method = RequestMethod.GET)
    public Employee getEploye(@PathVariable Integer id){
        Optional<Employee> byId = employeeRepo.findById(id);
        if (byId.isPresent()){
            return byId.get();
        }else return null;
    }

}
