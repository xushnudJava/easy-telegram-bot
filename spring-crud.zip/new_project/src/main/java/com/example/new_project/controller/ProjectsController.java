package com.example.new_project.controller;

import com.example.new_project.dto.ProjectDto;
import com.example.new_project.entity.Employee;
import com.example.new_project.entity.Projects;
import com.example.new_project.entity.Tasks;
import com.example.new_project.entity.Team;
import com.example.new_project.repo.EmployeeRepo;
import com.example.new_project.repo.ProjectRepo;
import com.example.new_project.repo.TasksRepo;
import com.example.new_project.repo.TeamRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@RestController
public class ProjectsController {
    @Autowired
    EmployeeRepo employeeRepo;
    @Autowired
    TasksRepo tasksRepo;
    @Autowired
    ProjectRepo projectRepo;
    @Autowired
    TeamRepo teamRepo;
    @RequestMapping(value = "/project",method = RequestMethod.POST)
    public String addProject(@RequestBody ProjectDto projectDto){
        Projects projects = new Projects();
        Optional<Employee> byId = employeeRepo.findById(projectDto.getManager_id());
        if (byId.isPresent()){
            projects.setManager(byId.get());
            Optional<Employee> byId1 = employeeRepo.findById(projectDto.getAsisManager_id());
            if (byId1.isPresent()){
                projects.setAsisManager(byId1.get());
                Team byName = teamRepo.findByName(projectDto.getTeam());
                if (byName != null){
                    projects.setTeam(projectDto.getTeam());
                    if (projectDto.getTitle() != null) projects.setTitle(projectDto.getTitle());
                    if (projectDto.getDescription() != null) projects.setDescription(projectDto.getDescription());
                    if (projectDto.getAttachments() != null) projects.setAttachments(projectDto.getAttachments());
                    if (projectDto.getStartDate() != null) projects.setStartDate(projectDto.getStartDate());
                    if (projectDto.getEndDate() != null) projects.setEndDate(projectDto.getEndDate());
                    if (projectDto.getDeadLine() != null) projects.setDeadLine(projectDto.getDeadLine());
                    if (projectDto.getStatus() != null) projects.setStatus(projectDto.getStatus());
                    Set<Tasks> tasksSet = new HashSet<>();
                    for (Integer integer : projectDto.getTasksList_id()) {
                        Optional<Tasks> byId2 = tasksRepo.findById(integer);
                        if (byId2.isPresent()){
                            tasksSet.add(byId2.get());
                        }
                    }
                    projects.setTasksList(tasksSet);
                    projectRepo.save(projects);
                    return "project added";
                }else return "Bunday team yo'q";
            }else return "AsisManager id bo'yicha employee topilmadi";
        }else return "manager id bo'yicha employee topilmadi";
    }
    @RequestMapping(value = "/project",method = RequestMethod.GET)
    public List<Projects>getProjectList(){
        return projectRepo.findAll();
    }
    @RequestMapping(value = "/project/{id}",method = RequestMethod.GET)
    public Projects getProject(@PathVariable Integer id){
        Optional<Projects> byId = projectRepo.findById(id);
        return byId.get();
    }
    @RequestMapping(value = "/project/{id}",method = RequestMethod.DELETE)
    public String deleteProject(@PathVariable Integer id){
        Optional<Projects> byId = projectRepo.findById(id);
        if (byId.isPresent()){
            projectRepo.delete(byId.get());
            return "Project deleted";
        }else return "bunday id bo'yicha project topilmadi";
    }
    @RequestMapping(value = "/project/{id}",method = RequestMethod.PUT)
    public String updateProject(@PathVariable Integer id, @RequestBody ProjectDto projectDto){
        Optional<Projects> byId = projectRepo.findById(id);
        if (byId.isPresent()){
            Projects projects = byId.get();
            if (projectDto.getManager_id() != null){
                Optional<Employee> byId1 = employeeRepo.findById(projectDto.getManager_id());
                if (byId1.isPresent()) projects.setManager(byId1.get());
            }
            if (projectDto.getAsisManager_id() != null){
                Optional<Employee> byId1 = employeeRepo.findById(projectDto.getAsisManager_id());
                if (byId1.isPresent()) projects.setAsisManager(byId1.get());
            }
            if (projectDto.getTeam() != null){
                Team byName = teamRepo.findByName(projectDto.getTeam());
                if (byName != null) projects.setTeam(byName.getName());
            }
            if (projectDto.getTitle() != null) projects.setTitle(projectDto.getTitle());
            if (projectDto.getDescription() != null) projects.setDescription(projectDto.getDescription());
            if (projectDto.getAttachments() != null) projects.setAttachments(projectDto.getAttachments());
            if (projectDto.getStartDate() != null) projects.setStartDate(projectDto.getStartDate());
            if (projectDto.getEndDate() != null) projects.setEndDate(projectDto.getEndDate());
            if (projectDto.getDeadLine() != null) projects.setDeadLine(projectDto.getDeadLine());
            if (projectDto.getStatus() != null) projects.setStatus(projectDto.getStatus());
            if (projectDto.getTasksList_id() != null){
                Set<Tasks>tasksSet = new HashSet<>();
                for (Integer integer : projectDto.getTasksList_id()) {
                    Optional<Tasks> byId1 = tasksRepo.findById(integer);
                    if (byId1.isPresent()){
                        tasksSet.add(byId1.get());
                    }
                }
                projects.setTasksList(tasksSet);

            }
            projectRepo.save(projects);
            return "updated Project";
        }else return "id bo'yicha project topilmadi";
    }
}
