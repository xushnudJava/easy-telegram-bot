package com.example.new_project.controller;

import com.example.new_project.dto.RequestDto;
import com.example.new_project.entity.Employee;
import com.example.new_project.entity.Requests;
import com.example.new_project.repo.EmployeeRepo;
import com.example.new_project.repo.RequestsRepo;
import jdk.jfr.Percentage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Optional;

@RestController
public class RequestController {
    @Autowired
    EmployeeRepo employeeRepo;
    @Autowired
    RequestsRepo requestsRepo;
    @RequestMapping(value = "/request",method = RequestMethod.POST)
    public String addRequest(@RequestBody RequestDto requestsDto){
        Optional<Employee> byId = employeeRepo.findById(requestsDto.getEmployee_id());
        if (byId.isPresent()){
            Employee employee = byId.get();
            Requests requests = new Requests();
            requests.setRequestType(requestsDto.getRequestType());
            requests.setEmployee(employee);
            requests.setStatus(requestsDto.getStatus());
            requests.setFromDate(requestsDto.getFromDate());
            requests.setToDate(requestsDto.getToDate());
            requestsRepo.save(requests);
            return "Request added";
        }else return "Employee id bo'yicha employee topilmadi";
    }
    @RequestMapping(value = "/request/{id}",method = RequestMethod.PUT)
    public String updateRequest(@PathVariable Integer id, @RequestBody RequestDto requestDto){
        Optional<Requests> byId = requestsRepo.findById(id);
        if (byId.isPresent()){
            Optional<Employee> byId1 = employeeRepo.findById(requestDto.getEmployee_id());
            if (byId1.isPresent()){
                Employee employee = byId1.get();
                Requests requests = byId.get();
                if (requestDto.getRequestType() != null) requests.setRequestType(requestDto.getRequestType());
                if (requestDto.getFromDate() != null) requests.setFromDate(requestDto.getFromDate());
                if (requestDto.getToDate() != null) requests.setToDate(requestDto.getToDate());
                if (requestDto.getStatus() != null) requests.setStatus(requestDto.getStatus());
                requests.setEmployee(employee);
                requestsRepo.save(requests);
                return "update request";
            }else return "employee id topilmadi";
        }else return "Bunday id dagi request yo'q";
    }
    @RequestMapping(value = "/request/{id}",method = RequestMethod.DELETE)
    public String deleteRequest(@PathVariable Integer id){
        Optional<Requests> byId = requestsRepo.findById(id);
        if (byId.isPresent()){
            requestsRepo.delete(byId.get());
            return "request deleted";
        }else return "error";
    }
    @RequestMapping(value = "/request/{id}",method = RequestMethod.GET)
    public Requests getRequest(@PathVariable Integer id){
        Optional<Requests> byId = requestsRepo.findById(id);
        return byId.get();
    }
    @RequestMapping(value = "/request",method = RequestMethod.GET)
    public List<Requests> getRequestList(){
        return requestsRepo.findAll();
    }
    @RequestMapping(value = "/requests/{id}",method = RequestMethod.GET)
    public List<Requests> getRequests(@PathVariable Integer id){
        Optional<Employee> byId = employeeRepo.findById(id);
        if (byId.isPresent()){
            List<Requests> allByEmployee = requestsRepo.findAllByEmployee(byId.get());
            return allByEmployee;
        }else return null;
    }




}
