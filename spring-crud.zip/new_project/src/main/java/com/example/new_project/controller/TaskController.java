package com.example.new_project.controller;

import com.example.new_project.dto.TaskDto;
import com.example.new_project.entity.Employee;
import com.example.new_project.entity.Projects;
import com.example.new_project.entity.Tasks;
import com.example.new_project.repo.EmployeeRepo;
import com.example.new_project.repo.ProjectRepo;
import com.example.new_project.repo.TasksRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Optional;

@RestController
public class TaskController {
    @Autowired
    TasksRepo tasksRepo;
    @Autowired
    EmployeeRepo employeeRepo;
    @Autowired
    ProjectRepo projectRepo;
    @RequestMapping(value = "/task",method = RequestMethod.GET)
    public List<Tasks> getTaskList(){
        return tasksRepo.findAll();
    }
    @RequestMapping(value = "/task/{id}",method = RequestMethod.GET)
    public Tasks getTask(@PathVariable Integer id){
        Optional<Tasks> byId = tasksRepo.findById(id);
        if (byId.isPresent()) return byId.get();
        else return null;
    }
    @RequestMapping(value = "/task/{id}",method = RequestMethod.DELETE)
    public String deleteTask(@PathVariable Integer id){
        Optional<Tasks> byId = tasksRepo.findById(id);
        if (byId.isPresent()){
            tasksRepo.delete(byId.get());
            return "deleted task";
        }
        else return "if bo'yicha task topilmadi";
    }
    @RequestMapping(value = "/task",method = RequestMethod.POST)
    public String addTask(@RequestBody TaskDto taskDto){
        Optional<Employee> byId = employeeRepo.findById(taskDto.getAssignee_id());
        if (byId.isPresent()){
            Tasks tasks = new Tasks();
            tasks.setAssignee(byId.get());
            Optional<Employee> byId1 = employeeRepo.findById(taskDto.getProject_id());
            if (byId1.isPresent()){
                tasks.setProject_id(taskDto.getProject_id());
                tasks.setTitle(taskDto.getTitle());
                tasks.setDescription(taskDto.getTitle());
                tasks.setType(taskDto.getType());
                tasks.setPriority(taskDto.getPriority());
                tasks.setStartDate(taskDto.getStartDate());
                tasks.setEndDate(taskDto.getEndDate());
                tasks.setDeadLine(taskDto.getDeadLine());
                tasks.setEstimatedTime(taskDto.getEstimatedTime());
                tasks.setSpentTime(taskDto.getSpentTime());
                tasks.setAttachment(taskDto.getAttachment());
                tasks.setStatus(taskDto.getStatus());
                tasks.setComments(taskDto.getComments());
                tasksRepo.save(tasks);
                return "task added";
            }else return "project id bo'yicha project topilamdi";
        }else return "assign id bo'yicha employe topilmadi";
    }
    @RequestMapping(value = "/tasl/{id}",method = RequestMethod.PUT)
    public String updateTask(@PathVariable Integer id, @RequestBody TaskDto taskDto){
        Optional<Tasks> byId = tasksRepo.findById(id);
        if (byId.isPresent()){
            Tasks tasks = byId.get();
            if (taskDto.getAssignee_id() != null){
                Optional<Employee> byId1 = employeeRepo.findById(taskDto.getAssignee_id());
                if(byId1.isPresent()) tasks.setAssignee(byId1.get());
            }
            if (taskDto.getProject_id() != null){
                Optional<Projects> byId1 = projectRepo.findById(taskDto.getProject_id());
                if (byId1.isPresent()) tasks.setProject_id(taskDto.getProject_id());
            }
            if (taskDto.getTitle() != null) tasks.setTitle(taskDto.getTitle());
            if (taskDto.getDescription() != null) tasks.setDescription(taskDto.getDescription());
            if (taskDto.getType() != null) tasks.setType(taskDto.getType());
            if (taskDto.getPriority() != null) tasks.setPriority(taskDto.getPriority());
            if (taskDto.getStartDate() != null) tasks.setStartDate(taskDto.getStartDate());
            if (taskDto.getEndDate() != null) tasks.setEndDate(taskDto.getEndDate());
            if (taskDto.getDeadLine() != null) tasks.setDeadLine(taskDto.getDeadLine());
            if (taskDto.getEstimatedTime() != null) tasks.setEstimatedTime(taskDto.getEstimatedTime());
            if (taskDto.getSpentTime() != null) tasks.setSpentTime(taskDto.getSpentTime());
            if (taskDto.getAttachment() != null) tasks.setAttachment(taskDto.getAttachment());
            if (taskDto.getStatus() != null) tasks.setStatus(taskDto.getStatus());
            if (taskDto.getComments() != null) tasks.setComments(taskDto.getComments());
            tasksRepo.save(tasks);
            return "updated Task";
        }else return "id bo'yicha task topilmadi";
    }
}
