package com.example.new_project.controller;

import com.example.new_project.dto.TeamDto;
import com.example.new_project.entity.Employee;
import com.example.new_project.entity.Team;
import com.example.new_project.repo.EmployeeRepo;
import com.example.new_project.repo.TeamRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@RestController
public class TeamController {
    @Autowired
    TeamRepo teamRepo;
    @Autowired
    EmployeeRepo employeeRepo;
    @RequestMapping(value = "/team",method = RequestMethod.POST)
    public String addTeam(@RequestBody TeamDto teamDto){
        Team team = new Team();
        if (teamDto == null) return "error";
        Team byName = teamRepo.findByName(teamDto.getName());
        if (byName != null) {
            return "bunday team mavjud";
        }
        team.setName(teamDto.getName());
        Set<Employee> employees = new HashSet<>();
        for (Integer integer : teamDto.getEmployees_id()) {
            Optional<Employee> byId = employeeRepo.findById(integer);
            if (byId.isPresent())
                employees.add(byId.get());
        }
        team.setEmployees(employees);
        teamRepo.save(team);
        return "employee added";
    }
    @RequestMapping(value = "/team",method = RequestMethod.GET)
    public List<Team> getTeamList(){
        return teamRepo.findAll();
    }
    @RequestMapping(value = "/team/{id}",method = RequestMethod.GET)
    public Team getTeam(@PathVariable Integer id){
        return teamRepo.findById(id).get();
    }
    @RequestMapping(value = "/team/{id}",method = RequestMethod.DELETE)
    public String deleteTeam(@PathVariable Integer id){
        Optional<Team> byId = teamRepo.findById(id);
        if (byId.isPresent()){
            teamRepo.delete(byId.get());
            return "Team deleted";
        }else return "id bo'yicha team topilmadi";
    }
    @RequestMapping(value = "/team/{id}",method = RequestMethod.PUT)
    public String updateTeam(@PathVariable Integer id, @RequestBody TeamDto teamDto){
        Optional<Team> byId = teamRepo.findById(id);
        if (byId.isPresent()){
            Team team = byId.get();
            if (teamDto.getName() != null) team.setName(teamDto.getName());
            if (teamDto.getEmployees_id() != null){
                Set<Employee> employeeSet = new HashSet<>();
                for (Integer integer : teamDto.getEmployees_id()) {
                    Optional<Employee> byId1 = employeeRepo.findById(integer);
                    if (byId1.isPresent()){
                        Employee employee = byId1.get();
                        employeeSet.add(employee);
                    }
                }
                team.setEmployees(employeeSet);
            }
            teamRepo.save(team);
            return "updated Team";
        }else return "id bo'yicha team topilmadi";
    }


}
