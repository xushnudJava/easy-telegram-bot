package com.example.new_project.dao;

import com.example.new_project.config.CustomFileReader;
import com.example.new_project.entity.Employee;
import com.example.new_project.repo.EmployeeRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class EmployeeDao implements BaseDao<Employee> {

    EmployeeRepo employeeRepo;
    private final String employeeFile = "src/main/resources/employee.csv";
    private final CustomFileReader fileReader = new CustomFileReader();
    @Override
    public List<Employee> findAll() throws IOException {
        return null;
    }
    public void readEmployeeFile() throws IOException {
        List<Employee> employees = new ArrayList<>();
        List<String> strings = fileReader.readFile(employeeFile);
        if (!strings.isEmpty()){
            strings.forEach(s -> employees.add(toEmployee(s)));
        }
        return;
    }
    private Employee toEmployee(String line){
        String[] strings = line.split(",");
        Employee employee = new Employee();
        employee.setFirstName(strings[0]);
        employee.setLastName(strings[1]);
        employee.setBirthday(strings[2]);
        employee.setGender(strings[3]);
        employee.setMaritalStatus(strings[4]);
        employee.setPhoneNumber(strings[5]);
        employee.setEmail_id(Integer.valueOf(strings[6]));
        employee.setMode(strings[7]);
        employee.setHireDate(strings[8]);
        employee.setResignationDate(strings[9]);
        employee.setProbationPeriod(Integer.valueOf(strings[10]));
        employee.setRole(strings[11]);
        employee.setSalary(Double.valueOf(strings[12]));
        employee.setReportingManager(strings[13]);
        employeeRepo.save(employee);
        return employee;
    }

}
