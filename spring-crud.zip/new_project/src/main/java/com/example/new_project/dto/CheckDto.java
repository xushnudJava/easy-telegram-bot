package com.example.new_project.dto;

import com.example.new_project.entity.Employee;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class CheckDto {
    private Integer id;
    private String date;
    private String check_in;
    private String check_out;

    private Integer employee_id;
}
