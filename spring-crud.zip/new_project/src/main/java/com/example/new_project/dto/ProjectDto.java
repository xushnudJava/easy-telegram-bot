package com.example.new_project.dto;

import com.example.new_project.entity.Employee;
import com.example.new_project.entity.Tasks;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
@AllArgsConstructor
@NoArgsConstructor
@Data
public class ProjectDto {
    private  Integer id;

    private String title;
    private String description;

    private Integer manager_id;


    private Integer asisManager_id;

    private String team;

    private List<Integer> tasksList_id;
    private String attachments;
    private String startDate;
    private String endDate;
    private String deadLine;
    private String status;
}
