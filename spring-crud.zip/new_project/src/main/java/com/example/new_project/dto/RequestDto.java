package com.example.new_project.dto;

import com.example.new_project.entity.Employee;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data

public class RequestDto {
    private Integer id;
    private String requestType;
    private String fromDate;
    private String toDate;
    private Boolean status;
    private Integer employee_id;
}
