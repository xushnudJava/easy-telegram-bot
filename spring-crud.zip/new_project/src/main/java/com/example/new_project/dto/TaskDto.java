package com.example.new_project.dto;

import com.example.new_project.entity.Employee;
import jakarta.persistence.OneToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class TaskDto {
    private Integer id;
    private String title;
    private String description;

    private Integer assignee_id;
    private String type;
    private String priority;
    private String startDate;
    private String endDate;
    private String deadLine;
    private String estimatedTime;
    private String spentTime;
    private Integer project_id;
    private String attachment;
    private String status;
    private String comments;
}
