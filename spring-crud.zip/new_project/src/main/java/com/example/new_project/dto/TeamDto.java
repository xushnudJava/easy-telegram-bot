package com.example.new_project.dto;

import com.example.new_project.entity.Employee;
import jakarta.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class TeamDto {
    private Integer id;
    private String name;
    @OneToMany
    private List<Integer> employees_id;
}
