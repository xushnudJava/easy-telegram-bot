package com.example.new_project.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class Employee {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String firstName;
    private String lastName;
    private String birthday;
    private String gender;
    private String maritalStatus;
    private String phoneNumber;
    private Integer email_id;
    private String mode;
    private String hireDate;
    private String resignationDate;
    private Integer probationPeriod;
    private String role;
    private Double salary;
    private String reportingManager;
}
