package com.example.new_project.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class Projects {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private  Integer id;

    private String title;
    private String description;
    @OneToOne
    private Employee manager;

    @OneToOne
    private Employee asisManager;

    private String team;
    @OneToMany
    private Set<Tasks> tasksList;
    private String attachments;
    private String startDate;
    private String endDate;
    private String deadLine;
    private String status;
}
