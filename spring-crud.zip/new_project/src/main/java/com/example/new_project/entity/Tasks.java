package com.example.new_project.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class Tasks {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String title;
    private String description;
    @OneToOne
    private Employee assignee;
    private String type;
    private String priority;
    private String startDate;
    private String endDate;
    private String deadLine;
    private String estimatedTime;
    private String spentTime;
    private Integer project_id;
    private String attachment;
    private String status;
    private String comments;
}
