package com.example.new_project.repo;

import com.example.new_project.entity.Check_in_out;
import com.example.new_project.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface Check_in_outRepo extends JpaRepository<Check_in_out,Integer> {
    List<Check_in_out> findAllByEmployee(Employee employee);
}
