package com.example.new_project.repo;

import com.example.new_project.entity.Candidates;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CondidatesRepo extends JpaRepository<Candidates,Integer> {
}
