package com.example.new_project.repo;

import com.example.new_project.entity.Employee;
import com.example.new_project.entity.Requests;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RequestsRepo extends JpaRepository<Requests,Integer> {
    List<Requests> findAllByEmployee(Employee employee);
}
