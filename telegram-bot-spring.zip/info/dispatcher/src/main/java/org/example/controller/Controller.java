package org.example.controller;

import org.example.repository.InfoRepository;
import org.example.entity.Foydalanuvchi;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.methods.ParseMode;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.objects.Message;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.ReplyKeyboardMarkup;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.buttons.KeyboardButton;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.buttons.KeyboardRow;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@Component
public class Controller extends TelegramLongPollingBot {
    @Override
    public String getBotUsername() {
        return "iticinfobot";
    }

    @Override
    public String getBotToken() {
        return "5901443949:AAE2OsZv2_tP6LhmYUR97v9qTUVQ53_0KR4";
    }
    List<String>strings = new ArrayList<>();
    List<List<String>>allString = new ArrayList<>();
    boolean kk = false;
    int c = 0;
    static int index;
    HashMap<Long,Integer> user_value;
    @Autowired
    InfoRepository infoRepository;
    static List<String>users = new ArrayList<>();
    static List<Integer>userLang = new ArrayList<>();
    static boolean bor = false;
    static List<Integer>valueUsers = new ArrayList<>();

    static List<String>list = list(0);
    static final List<String>enlist =list_en();
    static final  List<String>uzlist = list(0);
    static final  List<String>rulist = list_ru();
    static final List<List<String >> langList = new ArrayList<>();
    @Override
    public void onUpdateReceived(Update update) {
        langList.add(uzlist);
        langList.add(enlist);
        langList.add(rulist);


        if (update.hasMessage()){
            Message message = update.getMessage();
            if (message.hasText()){

                index = bormi(String.valueOf(message.getChatId()));
                String text = message.getText();
                SendMessage sendMessage = new SendMessage();
                sendMessage.setChatId(message.getChatId());
                sendMessage.setParseMode(ParseMode.MARKDOWN);
                if (text.equals("/start")){
                    index = bormi(String.valueOf(message.getChatId()));
                    valueUsers.set(index,0);
                    sendMessage.setText("Xush kelibsiz quyidagi savollarga javob bering");
                    ReplyKeyboardMarkup replyKeyboardMarkup = new ReplyKeyboardMarkup();
                    replyKeyboardMarkup.setResizeKeyboard(true);
                    List<KeyboardRow>keyboardRowList = new ArrayList<>();


                    KeyboardRow keyboardRow1 = new KeyboardRow();
                    KeyboardButton keyboardButton1 = new KeyboardButton();
                    keyboardButton1.setText("uz\uD83C\uDDFA\uD83C\uDDFF");
                    keyboardRow1.add(keyboardButton1);

                    KeyboardRow keyboardRow2 = new KeyboardRow();
                    KeyboardButton keyboardButton2 = new KeyboardButton();
                    keyboardButton2.setText("en\uD83C\uDDFA\uD83C\uDDF8");
                    keyboardRow1.add(keyboardButton2);

                    KeyboardRow keyboardRow3 = new KeyboardRow();
                    KeyboardButton keyboardButton3 = new KeyboardButton();
                    keyboardButton3.setText("ru\uD83C\uDDF7\uD83C\uDDFA");
                    keyboardRow3.add(keyboardButton3);

                    keyboardRowList.add(keyboardRow1);
                    keyboardRowList.add(keyboardRow2);
                    keyboardRowList.add(keyboardRow3);
                    replyKeyboardMarkup.setKeyboard(keyboardRowList);

                    sendMessage.setReplyMarkup(replyKeyboardMarkup);
                    kk = true;
                    strings = allString.get(index);
                    strings.clear();
                    strings.add(message.getFrom().getUserName());
                    strings.add(String.valueOf(message.getChatId()));
                    allString.set(index,strings);
                    strings.clear();
                }else if (kk && text.equals("uz\uD83C\uDDFA\uD83C\uDDFF")) {
                    index = bormi(String.valueOf(message.getChatId()));
                    userLang.set(index,0);

                    list = uzlist;
                    sendMessage.setText(langList.get(userLang.get(index)).get(0));
                    valueUsers.set(index,1);
                }else if(kk && text.equals("en\uD83C\uDDFA\uD83C\uDDF8")){
                    index = bormi(String.valueOf(message.getChatId()));

                    userLang.set(index,1);
                    list = enlist;

                    sendMessage.setText(langList.get(userLang.get(index)).get(0));
                    valueUsers.set(index,1);
                }else if(kk && text.equals("ru\uD83C\uDDF7\uD83C\uDDFA")){
                    index = bormi(String.valueOf(message.getChatId()));

                    userLang.set(index,2);
                    sendMessage.setText(langList.get(userLang.get(index)).get(0));
                    valueUsers.set(index,1);
                    list = rulist;

                }
                else if (valueUsers.get(index) > 0 && valueUsers.get(index) != 17){


                    index = bormi(String.valueOf(message.getChatId()));
                    int b = valueUsers.get(index);
                    strings = allString.get(index);
                    strings.add(text);
                    allString.set(index,strings);
                    sendMessage.setText(langList.get(userLang.get(index)).get(b++));
                    valueUsers.set(index,b);
                    if (b == 17 && strings.size() == 18) {
                        valueUsers.set(index,0);

                        Foydalanuvchi foydalanuvchi = new Foydalanuvchi();
                        foydalanuvchi.setUsername(strings.get(0));
                        foydalanuvchi.setChatId(strings.get(1));
                        foydalanuvchi.setDes1(strings.get(2));
                        foydalanuvchi.setDes2(strings.get(3));
                        foydalanuvchi.setDes3(strings.get(4));
                        foydalanuvchi.setDes4(strings.get(5));
                        foydalanuvchi.setDes5(strings.get(6));
                        foydalanuvchi.setDes6(strings.get(7));
                        foydalanuvchi.setDes7(strings.get(8));
                        foydalanuvchi.setDes8(strings.get(9));
                        foydalanuvchi.setDes9(strings.get(10));
                        foydalanuvchi.setDes10(strings.get(11));
                        foydalanuvchi.setDes11(strings.get(12));
                        foydalanuvchi.setDes12(strings.get(13));
                        foydalanuvchi.setDes13(strings.get(14));
                        foydalanuvchi.setDes14(strings.get(15));
                        foydalanuvchi.setDes15(strings.get(16));
                        foydalanuvchi.setDes16(strings.get(17));
                        infoRepository.save(foydalanuvchi);
                        strings.clear();
                        allString.set(index,strings);
                    }
                    strings.clear();


                }else sendMessage.setText(text);

                    try {
                        execute(sendMessage);


                    } catch (TelegramApiException e) {
                        throw new RuntimeException(e);
                    }

            }
        }
    }
    public int bormi(String s){
        int c1;
        bor = false;
        c1 = -1;
        if (users == null){
            users.add(s);
            valueUsers.add(0);
            userLang.add(0);
            allString.add(strings);
            return 0;
        }
        for (String str : users){
            c1++;
            if (s.equals(str)){
                bor = true;
                break;
            }

        }
        if (bor) {
            return c1;
        }
        users.add(s);
        valueUsers.add(0);
        userLang.add(0);
        allString.add(strings);
        return c1+1;
    }
    public static List<String> list(int n){
        List<List<String>> listList = new ArrayList<>();
        List<String>strings1 =new ArrayList<>();
        strings1.add("tashkil qilingan yili");
        strings1.add("missiyasi");
        strings1.add("yo'nalishlari");
        strings1.add("ILTIMOS ASOSIY XUSUSIYATLARINI YORITGAN HOLDA, KOMPANIYANGIZ HAQIDA UMUMIY MA'LUMOT BERING:");
        strings1.add("TAKLIF ETILGAN XIZMATLAR / MAHSULOTLAR");
        strings1.add("ILTIMOS MAQSADLI BOZORINGIZNI VA SIZ TAKLIF QILAYOTGAN XIZMATLAR YOKI MAHSULOTLARNI TAVSIFLANG. SIZNING MAHSULOTINGIZ/XIZMATINGIZ MIJOZLARINGIZGA NIMA BERADI?");
        strings1.add("ILTIMOS SIZNING XIZMATINGIZ/MAHSULOTINGIZ USHBU YO‘NALISHDA QANDAY YORDAM BERISHI HAQIDA BATAFSIL TUSHUNTIRISH BILAN ISHLAYOTGAN YO‘NALISHLARNI KIRITING.");
        strings1.add("XODIMLAR SONI VA MUTAXASSISLIGI Masalan\n" +
                "10 ta Python dasturchilar\n" +
                "  15 Java dasturchilari va boshqalar\n" +
                "20 ta C++ dasturchilar\n");
        strings1.add("MUTAXASSISLIGI DARAJASI (%) Masalan\n" +
                "30% senior daraja\n" +
                " 20% middle daraja\n" +
                "50% junior daraja\n");
        strings1.add("LOYIHALARNING UMUMIY QIYMATI ($) \n" +
                "(ixtiyoriy)\n");
        strings1.add("MUVAFFAQIYATLI LOYIHALAR " +
                "ILTIMOS ASOSIY XUSUSIYATLARINI YORITGAN HOLDA, KOMPANIYANGIZ BAJARAYOTGAN MUVAFFAQIYATLI LOYIHALARNI TAVSIFINI BERING:");
        strings1.add("BIZNING HAMKORLARIMIZ/MIJOZLARIMIZ" +
                "ILTIMOS MIJOZLAR VA HAMKORLAR NOMLARI VA LOGOLARINI KIRITING:");
        strings1.add("BIZ BILAN BOG‘LANING" +
                "EMAIL:");
        strings1.add("TELEFON:");
        strings1.add("MANZIL:");
        strings1.add("WEB-SAYT:");
        strings1.add("Etiboringiz uchun rahmat");
        return strings1;
    }
    public static List<String>list_en (){
        List<String>enList = new ArrayList<>();
        enList.add("YEAR FOUNDED:");
        enList.add("MISSION:");
        enList.add("DIRECTIONS (BRIEFLY):");
        enList.add("PLEASE GIVE AN OVERVIEW ABOUT YOUR COMPANY, HIGHLIGHTING MAIN FEATURES:");
        enList.add("OFFERED SERVICES / PRODUCTS");
        enList.add("PLEASE DESCRIBE YOUR TARGET MARKET AND SERVICES OR PRODUCTS YOU OFFER. WHAT YOUR PRODUCT/SERVICE GIVES TO YOUR CLIENTS?  ");
        enList.add("DIRECTIONS / INDUSTRIES " +
                "PLEASE INSERT DIRECTIONS YOU WORK IN WITH DETAILED EXPLANATION OF HOW YOUR SERVICE/PRODUCT HELPS IN THIS DIRECTION:   ");
        enList.add("NUMBER AND SPECIALIZATION OF EMPLOYEES \n" +
                "For example\n" +
                "10 Python developers\n" +
                " 15 Java developers etc.\n" +
                "20 C++ developers\n");
        enList.add("% OF SENIORITY\n" +
                "For example\n" +
                "30% senior level\n" +
                " 20% middle level\n" +
                "50% junior level\n");
        enList.add("TOTAL SUM OF PROJECTS (IN $)\n" +
                "(optional)\n");
        enList.add("SUCCESSFUL PROJECTS" +
                "PLEASE GIVE A DESCRIPTION OF SUCCESSFUL PROJECTS YOUR COMPANY EXECUTED, HIGHLIGHTING MAIN FEATURES:");
        enList.add("WE WORK WITH" +
                "PLEASE WRITE CLIENTS AND PARTNER COMPANIES NAMES AND LOGOS:");
        enList.add("CONTACT US" +
                "PLEASE GIVE A CONTACT INFORMATION ABOUT YOUR ORGANIZATION: \n" +
                "EMAIL:\n");
        enList.add("PHONE:");
        enList.add("ADRESS:");
        enList.add("WEBSITE:");
        enList.add("thank you for your attention");
        return enList;
    }
    public static List<String>list_ru(){
        List<String>ruList = new ArrayList<>();
        ruList.add("ДАТА ОСНОВАНИЯ:");
        ruList.add("МИССИЯ:");
        ruList.add("НАПРАВЛЕНИЯ (КРАТКО):");
        ruList.add("ПОЖАЛУЙСТА ДАЙТЕ ОБЗОР О ВАШЕЙ КОМПАНИИ, ВЫДЕЛЯЯ ОСНОВНЫЕ ХАРАКТЕРИСТИКИ:");
        ruList.add("ПРЕДЛАГАЕМЫЕ УСЛУГИ / ПРОДУКТЫ");
        ruList.add("ПОЖАЛУЙСТА ОПИШИТЕ СВОЙ ЦЕЛЕВОЙ РЫНОК И УСЛУГИ ИЛИ ПРОДУКТЫ, КОТОРЫЕ ВЫ ПРЕДЛАГАЕТЕ. ЧТО ВАШ ПРОДУКТ/УСЛУГА ДАЕТ ВАШИМ КЛИЕНТАМ?");
        ruList.add("НАПРАВЛЕНИЯ / ИНДУСТРИИ " +
                "ПОЖЖАЛУЙСТА ВСТАВЬТЕ НАПРАВЛЕНИЯ, В КОТОРЫХ ВЫ РАБОТАЕТЕ, С ПОДРОБНЫМ ОБЪЯСНЕНИЕМ ТОГО, КАК ВАШ ПРОДУКТ/УСЛУГА ПОМОГАЕТ В ЭТОМ НАПРАВЛЕНИИ:");
        ruList.add("КОЛИЧЕСТВО И СПЕЦИАЛИЗАЦИЯ РАБОТНИКОВ\n" +
                "Например\n" +
                "10 разработчиков Python\n" +
                "  15 разработчиков Java \n" +
                "20 разработчиков C++\n");
        ruList.add("ГРАДАЦИЯ УРОВНЯ КВАЛИФИКАЦИИ (%)\n" +
                "Например\n" +
                "30% senior уровень\n" +
                " 20% middle уровень\n" +
                "50% junior уровень\n");
        ruList.add("ОБЩАЯ СУММА ВЫПОЛНЕННЫХ ПРОЕКТОВ ($)\n" +
                "(по желанию)\n");
        ruList.add("УСПЕШНЫЕ ПРОЕКТЫ" +
                "ПОЖАЛУЙСТА ОПИШИТЕ УСПЕШНЫЕ ПРОЕКТЫ, РЕАЛИЗОВАННЫЕ ВАШЕЙ КОМПАНИЕЙ, ВЫДЕЛЯЯ ОСНОВНЫЕ ОСОБЕННОСТИ:");
        ruList.add("МЫ СОТРУДНИЧАЕМ С" +
                "ПОЖАЛУЙСТА НАПИШИТЕ И ВСТАВЬТЕ НАЗВАНИЕ ЛОГОТИПЫ ПАРТНЕРОВ И КЛИЕНТОВ:");
        ruList.add("СВЯЖИТЕСЬ С НАМИ" +
                "ПОЖАЛУЙСТА НАПИШИТЕ КОНТАКТНУЮ ИНФОРМАЦИЮ ДЛЯ СВЯЗИ:\n" +
                "EMAIL:\n");
        ruList.add("ТЕЛЕФОН:");
        ruList.add("АДРЕС:");
        ruList.add("САЙТ:");
        ruList.add("Спасибо за внимание");
        return ruList;

    }
}
