package org.example.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "infom")
public class Foydalanuvchi {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String username;
    private String chatId;
    private String des1;
    private String des2;
    private String des3;
    private String des4;
    private String des5;
    private String des6;
    private String des7;
    private String des8;
    private String des9;
    private String des10;
    private String des11;
    private String des12;
    private String des13;
    private String des14;
    private String des15;
    private String des16;
}
