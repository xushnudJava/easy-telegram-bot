package org.example.repository;

import org.example.entity.Foydalanuvchi;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InfoRepository extends JpaRepository<Foydalanuvchi,Integer> {

}
