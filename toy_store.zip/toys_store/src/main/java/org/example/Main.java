package org.example;

import org.example.ui.AppUI;
import org.example.utils.BaseUtils;

public class Main {
    public static void main(String[] args) {
        BaseUtils.println("\n\n*************** Project: Cosmetics warehouse search system *****************");
        BaseUtils.println("--------------- Author: (firstname surname) ---------------");
        BaseUtils.println("--------------- Email: firstnamesurname@gmail.com ---------------");
        BaseUtils.println("--------------- Creation date: since 06/06/2023 00:55 ---------------");
        BaseUtils.println("--------------- Version: version-0.0.1 ---------------");
        AppUI appUI = new AppUI();
        appUI.run();
    }
}