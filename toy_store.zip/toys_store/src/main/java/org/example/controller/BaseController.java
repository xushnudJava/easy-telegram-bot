package org.example.controller;

public interface BaseController {
    void showAll(String sort);

    void findByID();

    void findByColor();
    void findByName();

    void filterByPrice();
}
