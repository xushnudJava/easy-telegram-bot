package org.example.controller;

import org.example.domain.CarToys;
import org.example.dtos.DataDTO;
import org.example.dtos.ResponseEntity;
import org.example.service.CarToysService;
import org.example.service.SoftToysService;
import org.example.utils.BaseUtils;

import java.util.List;

public class CarToysController implements BaseController{
    private final CarToysService service = new CarToysService();
    @Override
    public void showAll(String sort) {
        ResponseEntity<DataDTO<List<CarToys>>> responseEntity = service.findAll(sort);
        BaseUtils.print(BaseUtils.gson.toJson(responseEntity));
    }

    @Override
    public void findByID() {
        BaseUtils.print("Enter id: ");
        ResponseEntity<DataDTO<List<CarToys>>> responseEntity = service.findById(BaseUtils.readLong());
        BaseUtils.print(BaseUtils.gson.toJson(responseEntity));
    }

    @Override
    public void findByColor() {
        BaseUtils.print("Enter color: ");
        ResponseEntity<DataDTO<List<CarToys>>> responseEntity = service.findByColor(BaseUtils.readText());
        BaseUtils.print(BaseUtils.gson.toJson(responseEntity));
    }

    @Override
    public void findByName() {
        BaseUtils.print("Enter name: ");
        ResponseEntity<DataDTO<List<CarToys>>> responseEntity = service.findByName(BaseUtils.readText());
        BaseUtils.print(BaseUtils.gson.toJson(responseEntity));
    }

    @Override
    public void filterByPrice() {
        BaseUtils.print("Enter min: ");
        Double min = BaseUtils.readDouble();
        BaseUtils.print("Enter max: ");
        Double max = BaseUtils.readDouble();
        ResponseEntity<DataDTO<List<CarToys>>> responseEntity = service.findByPrice(min, max);
        BaseUtils.print(BaseUtils.gson.toJson(responseEntity));
    }

    public void findBymaterial() {
        BaseUtils.print("Enter material: ");
        ResponseEntity<DataDTO<List<CarToys>>> responseEntity = service.findBymaterial(BaseUtils.readText());
        BaseUtils.print(BaseUtils.gson.toJson(responseEntity));
    }

    public void findByweight() {
        BaseUtils.print("Enter time weight: ");
        ResponseEntity<DataDTO<List<CarToys>>> responseEntity = service.findByweight(BaseUtils.readText());
        BaseUtils.print(BaseUtils.gson.toJson(responseEntity));
    }
}
