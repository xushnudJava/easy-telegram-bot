package org.example.controller;

import org.example.domain.PuzzleToys;
import org.example.dtos.DataDTO;
import org.example.dtos.ResponseEntity;
import org.example.service.PuzzleToysService;

import org.example.utils.BaseUtils;

import java.util.List;

public class PuzzleToysController implements BaseController{
    private final PuzzleToysService service = new PuzzleToysService();
    @Override
    public void showAll(String sort) {
        ResponseEntity<DataDTO<List<PuzzleToys>>> responseEntity = service.findAll(sort);
        BaseUtils.print(BaseUtils.gson.toJson(responseEntity));
    }

    @Override
    public void findByID() {
        BaseUtils.print("Enter id: ");
        ResponseEntity<DataDTO<List<PuzzleToys>>> responseEntity = service.findById(BaseUtils.readLong());
        BaseUtils.print(BaseUtils.gson.toJson(responseEntity));
    }

    @Override
    public void findByColor() {
        BaseUtils.print("Enter color: ");
        ResponseEntity<DataDTO<List<PuzzleToys>>> responseEntity = service.findByColor(BaseUtils.readText());
        BaseUtils.print(BaseUtils.gson.toJson(responseEntity));
    }

    @Override
    public void findByName() {
        BaseUtils.print("Enter name: ");
        ResponseEntity<DataDTO<List<PuzzleToys>>> responseEntity = service.findByName(BaseUtils.readText());
        BaseUtils.print(BaseUtils.gson.toJson(responseEntity));
    }

    @Override
    public void filterByPrice() {
        BaseUtils.print("Enter min: ");
        Double min = BaseUtils.readDouble();
        BaseUtils.print("Enter max: ");
        Double max = BaseUtils.readDouble();
        ResponseEntity<DataDTO<List<PuzzleToys>>> responseEntity = service.findByPrice(min, max);
        BaseUtils.print(BaseUtils.gson.toJson(responseEntity));
    }

    public void findByminAge() {
        BaseUtils.print("Enter minAge: ");
        ResponseEntity<DataDTO<List<PuzzleToys>>> responseEntity = service.findByminAge(BaseUtils.readText());
        BaseUtils.print(BaseUtils.gson.toJson(responseEntity));
    }

    public void findBylevel() {
        BaseUtils.print("Enter time level: ");
        ResponseEntity<DataDTO<List<PuzzleToys>>> responseEntity = service.findBylevel(BaseUtils.readText());
        BaseUtils.print(BaseUtils.gson.toJson(responseEntity));
    }
}
