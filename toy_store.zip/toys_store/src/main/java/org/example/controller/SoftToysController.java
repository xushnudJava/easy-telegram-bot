package org.example.controller;

import org.example.domain.SoftToys;
import org.example.dtos.DataDTO;
import org.example.dtos.ResponseEntity;
import org.example.service.SoftToysService;
import org.example.utils.BaseUtils;

import java.util.List;

public class SoftToysController implements BaseController{
    private final SoftToysService service = new SoftToysService();
    @Override
    public void showAll(String sort) {
        ResponseEntity<DataDTO<List<SoftToys>>> responseEntity = service.findAll(sort);
        BaseUtils.print(BaseUtils.gson.toJson(responseEntity));
    }

    @Override
    public void findByID() {
        BaseUtils.print("Enter id: ");
        ResponseEntity<DataDTO<List<SoftToys>>> responseEntity = service.findById(BaseUtils.readLong());
        BaseUtils.print(BaseUtils.gson.toJson(responseEntity));
    }

    @Override
    public void findByColor() {
        BaseUtils.print("Enter color: ");
        ResponseEntity<DataDTO<List<SoftToys>>> responseEntity = service.findByColor(BaseUtils.readText());
        BaseUtils.print(BaseUtils.gson.toJson(responseEntity));
    }

    @Override
    public void findByName() {
        BaseUtils.print("Enter name: ");
        ResponseEntity<DataDTO<List<SoftToys>>> responseEntity = service.findByName(BaseUtils.readText());
        BaseUtils.print(BaseUtils.gson.toJson(responseEntity));
    }

    @Override
    public void filterByPrice() {
        BaseUtils.print("Enter min: ");
        Double min = BaseUtils.readDouble();
        BaseUtils.print("Enter max: ");
        Double max = BaseUtils.readDouble();
        ResponseEntity<DataDTO<List<SoftToys>>> responseEntity = service.findByPrice(min, max);
        BaseUtils.print(BaseUtils.gson.toJson(responseEntity));
    }

    public void findBymadeIn() {
        BaseUtils.print("Enter madeIn: ");
        ResponseEntity<DataDTO<List<SoftToys>>> responseEntity = service.findByMadeIn(BaseUtils.readText());
        BaseUtils.print(BaseUtils.gson.toJson(responseEntity));
    }
}
