package org.example.dao;

import org.example.config.CustomFileReader;
import org.example.domain.BaseDomain;
import org.example.domain.CarToys;
import org.example.domain.SoftToys;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CarToysDao implements BaseDao<CarToys> {
    private final String cartoysFile = "src/main/resources/cartoys.csv";
    private final CustomFileReader fileReader = new CustomFileReader();
    @Override
    public List<CarToys> findAll() throws IOException {
        return readCarToysFile();
    }
    public List<CarToys> readCarToysFile() throws IOException {
        List<CarToys> carToys = new ArrayList<>();
        List<String> strings =fileReader.readFile(cartoysFile);
        strings.forEach(s -> carToys.add(toCarToys(s)));
        return carToys;
    }

    private CarToys toCarToys(String line){
        String[] strings = line.split(",");
        return new CarToys(Long.valueOf(strings[0]), strings[1], strings[2], Double.parseDouble(strings[3]),
                Integer.valueOf(strings[4]), strings[5], strings[6], strings[7]);
    }
}
