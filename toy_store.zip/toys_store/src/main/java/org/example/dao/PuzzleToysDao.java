package org.example.dao;

import org.example.config.CustomFileReader;
import org.example.domain.PuzzleToys;
import org.example.domain.SoftToys;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class PuzzleToysDao implements BaseDao<PuzzleToys> {
    private final String puzzletoysFile = "src/main/resources/cartoys.csv";
    private final CustomFileReader fileReader = new CustomFileReader();
    @Override
    public List<PuzzleToys> findAll() throws IOException {
        return null;
    }
    public List<PuzzleToys> readPuzzleToysFile() throws IOException {
        List<PuzzleToys> puzzleToys = new ArrayList<>();
        List<String> strings = fileReader.readFile(puzzletoysFile);
        strings.forEach(s -> puzzleToys.add(toPuzzleToys(s)));
        return puzzleToys;
    }
    private PuzzleToys toPuzzleToys(String line){
        String[] strings = line.split(",");
        return new PuzzleToys(Long.valueOf(strings[0]), strings[1], strings[2], Double.parseDouble(strings[3]),
                Integer.valueOf(strings[4]), strings[5], Integer.valueOf(strings[6]), strings[7]);
    }
}
