package org.example.dao;

import org.example.config.CustomFileReader;
import org.example.domain.SoftToys;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class SoftToysDao implements BaseDao<SoftToys> {
    private final String softtoysFile = "src/main/resources/softtoys.csv";
    private final CustomFileReader fileReader = new CustomFileReader();
    @Override
    public List<SoftToys> findAll() throws IOException {
        return readSoftToysFile();
    }
    public List<SoftToys> readSoftToysFile() throws IOException {
        List<SoftToys> softToys = new ArrayList<>();
        List<String>strings =fileReader.readFile(softtoysFile);
        strings.forEach(s -> softToys.add(toSoftToys(s)));
        return softToys;
    }
    private SoftToys toSoftToys(String line){
        String[] strings = line.split(",");
        return new SoftToys(Long.valueOf(strings[0]), strings[1], strings[2], Double.parseDouble(strings[3]),
                Integer.valueOf(strings[4]), strings[5], Boolean.valueOf(strings[6]), strings[7]);
    }

}
