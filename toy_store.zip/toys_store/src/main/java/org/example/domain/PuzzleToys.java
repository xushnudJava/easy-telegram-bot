package org.example.domain;

public class PuzzleToys extends BaseDomain{
    private Integer minAge;
    private String level;
    public PuzzleToys(Long id, String name, String color, Double price, Integer amount, String manufactureDate,
                      Integer minAge, String level) {
        super(id, name, color, price, amount, manufactureDate);
        this.minAge = minAge;
        this.level = level;
    }

    public Integer getMinAge() {
        return minAge;
    }

    public void setMinAge(Integer minAge) {
        this.minAge = minAge;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }
}
