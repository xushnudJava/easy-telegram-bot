package org.example.domain;

public class SoftToys extends BaseDomain{
    private Boolean isCotton;
    private String madeIn;
    public SoftToys(Long id, String name, String color, Double price, Integer amount, String manufactureDate, Boolean isCotton, String madeIn) {
        super(id, name, color, price, amount, manufactureDate);
        this.isCotton = isCotton;
        this.madeIn = madeIn;
    }

    public Boolean getCotton() {
        return isCotton;
    }

    public void setCotton(Boolean cotton) {
        isCotton = cotton;
    }

    public String getMadeIn() {
        return madeIn;
    }

    public void setMadeIn(String madeIn) {
        this.madeIn = madeIn;
    }
}
