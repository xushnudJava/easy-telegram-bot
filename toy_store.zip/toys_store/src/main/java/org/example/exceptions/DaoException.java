package org.example.exceptions;

public class DaoException extends Exception{
    public DaoException(String message){
        super(message);
    }

}
