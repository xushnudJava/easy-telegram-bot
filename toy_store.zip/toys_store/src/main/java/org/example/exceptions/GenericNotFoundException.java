package org.example.exceptions;

public class GenericNotFoundException extends Exception{
    public GenericNotFoundException(String message){
        super(message);
    }
}
