package org.example.service;

import org.example.dtos.DataDTO;
import org.example.dtos.ResponseEntity;

import java.util.List;

public interface BaseService<T> {
    ResponseEntity<DataDTO<List<T>>>findAll(String sort);
    ResponseEntity<DataDTO<List<T>>>findById(Long id);
    ResponseEntity<DataDTO<List<T>>>findByName(String name);
    ResponseEntity<DataDTO<List<T>>>findByColor(String color);
    ResponseEntity<DataDTO<List<T>>>findByPrice(Double min, Double max);

}
