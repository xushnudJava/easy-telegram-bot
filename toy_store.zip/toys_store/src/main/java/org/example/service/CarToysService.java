package org.example.service;

import org.example.dao.CarToysDao;
import org.example.domain.CarToys;
import org.example.domain.CarToys;
import org.example.domain.CarToys;
import org.example.dtos.AppErrorDTO;
import org.example.dtos.DataDTO;
import org.example.dtos.ResponseEntity;
import org.example.exceptions.GenericNotFoundException;

import java.io.IOException;
import java.util.Comparator;
import java.util.List;

public class CarToysService implements BaseService<CarToys> {
    private final CarToysDao dao = new CarToysDao();
    public ResponseEntity<DataDTO<List<CarToys>>> findAll(String sort) {
        try {
            List<CarToys>carToys = dao.findAll();
            if (carToys.isEmpty()){
                throw new GenericNotFoundException("CarToys not found!");
            }
            switch (sort){
                case "1" -> carToys.sort(Comparator.comparing(CarToys::getId));
                case "2" -> carToys.sort(Comparator.comparing(CarToys::getPrice));
            }
            return new ResponseEntity<>(new DataDTO<>(carToys));
        } catch (IOException | GenericNotFoundException e) {
            return new ResponseEntity<>(new DataDTO<>(new AppErrorDTO(e.getMessage(), e.getMessage())), 400);
        }
    }
    FindServise findServise = new FindServise();

    @Override
    public ResponseEntity<DataDTO<List<CarToys>>> findById(Long id) {
        try {
            List<CarToys> carToys = dao.findAll().stream().filter(carToys1 ->
                   findServise.search(String.valueOf(id),String.valueOf(carToys1.getId())) ).toList();
            if (carToys == null) {
                throw new GenericNotFoundException("CarToys not found!");
            }
            return new ResponseEntity<>(new DataDTO<>(carToys),200);
        } catch (Exception e) {
            return new ResponseEntity<>(new DataDTO<>(new AppErrorDTO(e.getMessage(), e.getMessage())), 400);
        }
    }

    @Override
    public ResponseEntity<DataDTO<List<CarToys>>> findByName(String name) {
        try {
            List<CarToys> carToys = dao.findAll().stream().filter(carToys1 ->
                    findServise.search(name,carToys1.getName())).toList();
            if (carToys == null) {
                throw new GenericNotFoundException("CarToys not found!");
            }
            return new ResponseEntity<>(new DataDTO<>(carToys), 200);
        } catch (Exception e) {
            return new ResponseEntity<>(new DataDTO<>(new AppErrorDTO(e.getMessage(), e.getMessage())), 400);
        }
    }

    @Override
    public ResponseEntity<DataDTO<List<CarToys>>> findByColor(String color) {
        try {
            List<CarToys> carToys = dao.findAll().stream().filter(carToys1 ->
                    findServise.search(color,carToys1.getColor())).toList();
            if (carToys.isEmpty()) {
                throw new GenericNotFoundException("CarToys not found!");
            }
            return new ResponseEntity<>(new DataDTO<>(carToys), 200);
        } catch (Exception e) {
            return new ResponseEntity<>(new DataDTO<>(new AppErrorDTO(e.getMessage(), e.getMessage())), 400);
        }
    }

    @Override
    public ResponseEntity<DataDTO<List<CarToys>>> findByPrice(Double min, Double max) {
        try {
            List<CarToys> carToys = dao.findAll().stream().filter(carToys1 ->
                    carToys1.getPrice() >= min && carToys1.getPrice() <= max).toList();
            if (carToys.isEmpty()) {
                throw new GenericNotFoundException("CarToys not found!");
            }
            return new ResponseEntity<>(new DataDTO<>(carToys), 200);
        } catch (Exception e) {
            return new ResponseEntity<>(new DataDTO<>(new AppErrorDTO(e.getMessage(), e.getMessage())), 400);
        }
    }
    public ResponseEntity<DataDTO<List<CarToys>>> findBymaterial(String material) {
        try {
            List<CarToys> carToys = dao.findAll().stream().filter(carToys1 ->
                    findServise.search(material,carToys1.getMaterial())).toList();
            if (carToys.isEmpty()) {
                throw new GenericNotFoundException("CarToys not found!");
            }
            return new ResponseEntity<>(new DataDTO<>(carToys), 200);
        } catch (Exception e) {
            return new ResponseEntity<>(new DataDTO<>(new AppErrorDTO(e.getMessage(), e.getMessage())), 400);
        }
    }
    public ResponseEntity<DataDTO<List<CarToys>>> findByweight(String weight) {
        try {
            List<CarToys> carToys = dao.findAll().stream().filter(carToys1 ->
                    findServise.search(weight,carToys1.getWeight())).toList();
            if (carToys.isEmpty()) {
                throw new GenericNotFoundException("CarToys not found!");
            }
            return new ResponseEntity<>(new DataDTO<>(carToys), 200);
        } catch (Exception e) {
            return new ResponseEntity<>(new DataDTO<>(new AppErrorDTO(e.getMessage(), e.getMessage())), 400);
        }
    }
}
