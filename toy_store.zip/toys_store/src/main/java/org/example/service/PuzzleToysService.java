package org.example.service;



import org.example.dao.PuzzleToysDao;
import org.example.domain.PuzzleToys;
import org.example.dtos.AppErrorDTO;
import org.example.dtos.DataDTO;
import org.example.dtos.ResponseEntity;
import org.example.exceptions.GenericNotFoundException;

import java.io.IOException;
import java.util.Comparator;
import java.util.List;

public class PuzzleToysService implements BaseService<PuzzleToys> {
    FindServise findServise = new FindServise();
    private final PuzzleToysDao dao = new PuzzleToysDao();
    public ResponseEntity<DataDTO<List<PuzzleToys>>> findAll(String sort) {
        try {
            List<PuzzleToys>puzzleToys = dao.findAll();
            if (puzzleToys.isEmpty()){
                throw new GenericNotFoundException("PuzzleToys not found!");
            }
            switch (sort){
                case "1" -> puzzleToys.sort(Comparator.comparing(PuzzleToys::getId));
                case "2" -> puzzleToys.sort(Comparator.comparing(PuzzleToys::getPrice));
            }
            return new ResponseEntity<>(new DataDTO<>(puzzleToys));
        } catch (IOException | GenericNotFoundException e) {
            return new ResponseEntity<>(new DataDTO<>(new AppErrorDTO(e.getMessage(), e.getMessage())), 400);
        }
    }

    @Override
    public ResponseEntity<DataDTO<List<PuzzleToys>>> findById(Long id) {
        try {
            List<PuzzleToys> puzzleToys = dao.findAll().stream().filter(puzzleToys1 ->
                    findServise.search(String.valueOf(id),String.valueOf(puzzleToys1.getId()))).toList();
            if (puzzleToys == null) {
                throw new GenericNotFoundException("PuzzleToys not found!");
            }
            return new ResponseEntity<>(new DataDTO<>(puzzleToys),200);
        } catch (Exception e) {
            return new ResponseEntity<>(new DataDTO<>(new AppErrorDTO(e.getMessage(), e.getMessage())), 400);
        }
    }

    @Override
    public ResponseEntity<DataDTO<List<PuzzleToys>>> findByName(String name) {
        try {
            List<PuzzleToys> puzzleToys = dao.findAll().stream().filter(puzzleToys1 ->
                    findServise.search(name,puzzleToys1.getName())).toList();
            if (puzzleToys == null) {
                throw new GenericNotFoundException("PuzzleToys not found!");
            }
            return new ResponseEntity<>(new DataDTO<>(puzzleToys), 200);
        } catch (Exception e) {
            return new ResponseEntity<>(new DataDTO<>(new AppErrorDTO(e.getMessage(), e.getMessage())), 400);
        }
    }

    @Override
    public ResponseEntity<DataDTO<List<PuzzleToys>>> findByColor(String color) {
        try {
            List<PuzzleToys> puzzleToys = dao.findAll().stream().filter(puzzleToys1 ->
                    findServise.search(color,puzzleToys1.getColor())).toList();
            if (puzzleToys.isEmpty()) {
                throw new GenericNotFoundException("PuzzleToys not found!");
            }
            return new ResponseEntity<>(new DataDTO<>(puzzleToys), 200);
        } catch (Exception e) {
            return new ResponseEntity<>(new DataDTO<>(new AppErrorDTO(e.getMessage(), e.getMessage())), 400);
        }
    }

    @Override
    public ResponseEntity<DataDTO<List<PuzzleToys>>> findByPrice(Double min, Double max) {
        try {
            List<PuzzleToys> puzzleToys = dao.findAll().stream().filter(puzzleToys1 ->
                    puzzleToys1.getPrice() >= min && puzzleToys1.getPrice() <= max).toList();
            if (puzzleToys.isEmpty()) {
                throw new GenericNotFoundException("PuzzleToys not found!");
            }
            return new ResponseEntity<>(new DataDTO<>(puzzleToys), 200);
        } catch (Exception e) {
            return new ResponseEntity<>(new DataDTO<>(new AppErrorDTO(e.getMessage(), e.getMessage())), 400);
        }
    }
    public ResponseEntity<DataDTO<List<PuzzleToys>>> findByminAge(String minAge) {
        try {
            List<PuzzleToys> puzzleToys = dao.findAll().stream().filter(puzzleToys1 ->
                    findServise.search(minAge,String.valueOf(puzzleToys1.getMinAge()))).toList();
            if (puzzleToys.isEmpty()) {
                throw new GenericNotFoundException("PuzzleToys not found!");
            }
            return new ResponseEntity<>(new DataDTO<>(puzzleToys), 200);
        } catch (Exception e) {
            return new ResponseEntity<>(new DataDTO<>(new AppErrorDTO(e.getMessage(), e.getMessage())), 400);
        }
    }
    public ResponseEntity<DataDTO<List<PuzzleToys>>> findBylevel(String level) {
        try {
            List<PuzzleToys> puzzleToys = dao.findAll().stream().filter(puzzleToys1 ->
                    findServise.search(level,puzzleToys1.getLevel())).toList();
            if (puzzleToys.isEmpty()) {
                throw new GenericNotFoundException("PuzzleToys not found!");
            }
            return new ResponseEntity<>(new DataDTO<>(puzzleToys), 200);
        } catch (Exception e) {
            return new ResponseEntity<>(new DataDTO<>(new AppErrorDTO(e.getMessage(), e.getMessage())), 400);
        }
    }
}
