package org.example.service;

import org.example.dao.SoftToysDao;
import org.example.domain.SoftToys;
import org.example.dtos.AppErrorDTO;
import org.example.dtos.DataDTO;
import org.example.dtos.ResponseEntity;
import org.example.exceptions.GenericNotFoundException;

import java.io.IOException;
import java.util.Comparator;
import java.util.List;

public class SoftToysService implements BaseService<SoftToys>{
    private final SoftToysDao dao = new SoftToysDao();
    FindServise findServise = new FindServise();
    @Override
    public ResponseEntity<DataDTO<List<SoftToys>>> findAll(String sort) {
        try {
            List<SoftToys>softToys = dao.findAll();
            if (softToys.isEmpty()){
                throw new GenericNotFoundException("SoftToys not found!");
            }
            switch (sort){
                case "1" -> softToys.sort(Comparator.comparing(SoftToys::getId));
                case "2" -> softToys.sort(Comparator.comparing(SoftToys::getPrice));
            }
            return new ResponseEntity<>(new DataDTO<>(softToys));
        } catch (IOException | GenericNotFoundException e) {
            return new ResponseEntity<>(new DataDTO<>(new AppErrorDTO(e.getMessage(), e.getMessage())), 400);
        }
    }

    @Override
    public ResponseEntity<DataDTO<List<SoftToys>>> findById(Long id) {
        try {
            List<SoftToys> softToys = dao.findAll().stream().filter(softToys1 ->
                    findServise.search(String.valueOf(id),String.valueOf(softToys1.getId()))).toList();
            if (softToys == null) {
                throw new GenericNotFoundException("SoftToys not found!");
            }
            return new ResponseEntity<>(new DataDTO<>(softToys),200);
        } catch (Exception e) {
            return new ResponseEntity<>(new DataDTO<>(new AppErrorDTO(e.getMessage(), e.getMessage())), 400);
        }
    }

    @Override
    public ResponseEntity<DataDTO<List<SoftToys>>> findByName(String name) {
        try {
            List<SoftToys> softToys = dao.findAll().stream().filter(softToys1 ->
                    findServise.search(name,softToys1.getName())).toList();
            if (softToys == null) {
                throw new GenericNotFoundException("SoftToys not found!");
            }
            return new ResponseEntity<>(new DataDTO<>(softToys), 200);
        } catch (Exception e) {
            return new ResponseEntity<>(new DataDTO<>(new AppErrorDTO(e.getMessage(), e.getMessage())), 400);
        }
    }

    @Override
    public ResponseEntity<DataDTO<List<SoftToys>>> findByColor(String color) {
        try {
            List<SoftToys> softToys = dao.findAll().stream().filter(softToys1 ->
                    findServise.search(color,softToys1.getColor())).toList();
            if (softToys.isEmpty()) {
                throw new GenericNotFoundException("SoftToys not found!");
            }
            return new ResponseEntity<>(new DataDTO<>(softToys), 200);
        } catch (Exception e) {
            return new ResponseEntity<>(new DataDTO<>(new AppErrorDTO(e.getMessage(), e.getMessage())), 400);
        }
    }

    @Override
    public ResponseEntity<DataDTO<List<SoftToys>>> findByPrice(Double min, Double max) {
        try {
            List<SoftToys> softToys = dao.findAll().stream().filter(softToys1 ->
                    softToys1.getPrice() >= min && softToys1.getPrice() <= max).toList();
            if (softToys.isEmpty()) {
                throw new GenericNotFoundException("SoftToys not found!");
            }
            return new ResponseEntity<>(new DataDTO<>(softToys), 200);
        } catch (Exception e) {
            return new ResponseEntity<>(new DataDTO<>(new AppErrorDTO(e.getMessage(), e.getMessage())), 400);
        }
    }

    public ResponseEntity<DataDTO<List<SoftToys>>> findByMadeIn(String madeIn) {
        try {
            List<SoftToys> softToys = dao.findAll().stream().filter(softToys1 ->
                    findServise.search(madeIn,softToys1.getMadeIn())).toList();
            if (softToys.isEmpty()) {
                throw new GenericNotFoundException("SoftToys not found!");
            }
            return new ResponseEntity<>(new DataDTO<>(softToys), 200);
        } catch (Exception e) {
            return new ResponseEntity<>(new DataDTO<>(new AppErrorDTO(e.getMessage(), e.getMessage())), 400);
        }
    }
}
