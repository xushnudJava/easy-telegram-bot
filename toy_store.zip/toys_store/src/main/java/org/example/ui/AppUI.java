package org.example.ui;

import org.example.controller.CarToysController;
import org.example.controller.PuzzleToysController;
import org.example.controller.SoftToysController;
import org.example.utils.BaseUtils;

import java.util.Objects;

public class AppUI {
    private final SoftToysController softToysController = new SoftToysController();
    private final CarToysController carToysController = new CarToysController();
    private final PuzzleToysController puzzleToysController = new PuzzleToysController();
    public void run() {
        BaseUtils.println("\n\n1 -> Soft toys");
        BaseUtils.println("2 -> Car toys");
        BaseUtils.println("3 -> Puzzle toys");
        BaseUtils.println("q -> Quit");

        BaseUtils.print("-- Select operation: ");
        switch (BaseUtils.readText()) {
            case "1" -> softToysUI();
            case "2" -> carToysUI();
            case "3" -> puzzleToysUI();
            case "q" -> System.exit(0);
            default -> BaseUtils.println("Wrong choice!");
        }
        run();
    }

    private String baseUI() {
        BaseUtils.println("1 -> Show all");
        BaseUtils.println("2 -> Find by id");
        BaseUtils.println("3 -> Find by color");
        BaseUtils.println("4 -> Find by name");
        BaseUtils.println("5 -> Filter by price");
        BaseUtils.println("0 -> Back");

        BaseUtils.print("Select operation: ");
        return BaseUtils.readText();
    }
    private void softToysUI() {
        BaseUtils.println("\n\n6 -> Find by made in");
        switch (baseUI()) {
            case "1" -> showAllSoftToys();
            case "2" -> softToysController.findByID();
            case "3" -> softToysController.findByColor();
            case "4" -> softToysController.findByName();
            case "5" -> softToysController.filterByPrice();
            case "6" -> softToysController.findBymadeIn();
            case "0" -> run();
            default -> BaseUtils.println("Wrong choice!");
        }
        softToysUI();
    }

    private String showUI() {
        BaseUtils.println("\n\n1 -> Sort by id");
        BaseUtils.println("2 -> Sort by price");
        BaseUtils.println("0 -> Back");

        BaseUtils.print("-- Select operation: ");
        return BaseUtils.readText();
    }

    private void showAllSoftToys() {
        String operation = showUI();
        if (Objects.equals(operation, "0")) {
            softToysUI();
        }
        softToysController.showAll(operation);
        showAllSoftToys();
    }

    private void carToysUI() {
        BaseUtils.println("6 -> Find by made material");
        BaseUtils.println("7 -> Find by made weight");
        switch (baseUI()) {
            case "1" -> showAllCarToys();
            case "2" -> carToysController.findByID();
            case "3" -> carToysController.findByColor();
            case "4" -> carToysController.findByName();
            case "5" -> carToysController.filterByPrice();
            case "6" -> carToysController.findBymaterial();
            case "7" -> carToysController.findByweight();
            case "0" -> run();
            default -> BaseUtils.println("Wrong choice!");
        }
        carToysUI();
    }

    private void showAllCarToys() {
        String operation = showUI();
        if (Objects.equals(operation, "0")) {
            carToysUI();
        }
        carToysController.showAll(operation);
        showAllCarToys();
    }

    private void puzzleToysUI() {
        BaseUtils.println("\n\n6 -> Find by min age");
        BaseUtils.println("7 -> Find by level");
        switch (baseUI()) {
            case "1" -> showAllPuzzleToys();
            case "2" -> puzzleToysController.findByID();
            case "3" -> puzzleToysController.findByColor();
            case "4" -> puzzleToysController.findByName();
            case "5" -> puzzleToysController.filterByPrice();
            case "6" -> puzzleToysController.findByminAge();
            case "7" -> puzzleToysController.findBylevel();
            case "0" -> run();
            default -> BaseUtils.println("Wrong choice!");
        }
        puzzleToysUI();
    }

    private void showAllPuzzleToys() {
        String operation = showUI();
        if (Objects.equals(operation, "0")) {
            puzzleToysUI();
        }
        puzzleToysController.showAll(operation);
        showAllPuzzleToys();
    }
}
